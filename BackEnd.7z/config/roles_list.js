const ROLES_LIST = {
  Authorized: 5001,
  User: 3005,
  Public: 2001,
};

export default ROLES_LIST;
